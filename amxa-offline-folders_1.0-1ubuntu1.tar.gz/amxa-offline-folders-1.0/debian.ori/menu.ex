?package(amxa-offline-folders):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="amxa-offline-folders" command="/usr/bin/amxa-offline-folders"
